import glob
from src.document_loader import SupportDocumentLoader
from src.vector_store import VectorStore
from src.rag_chain import RAGChain

def main():
    loader = SupportDocumentLoader()
    documents = []

    # Load all ticket files
    for file in glob.glob("data/*"):
        documents.extend(loader.load(file))
        print(documents)
    # Build vector store
    vector_store = VectorStore()
    store = vector_store.build(documents)

    print("vector is done")

    # Initialize RAG chain
    rag = RAGChain(store)

    # Run query
    response = rag.run("Login issue on Chrome")

    print("\nAnswer:\n")
    print(response.content)

if __name__ == "__main__":
    main()
