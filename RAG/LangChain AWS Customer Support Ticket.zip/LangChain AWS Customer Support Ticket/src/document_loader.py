import json
import xml.etree.ElementTree as ET
from pathlib import Path
# from langchain.schema import Document
from langchain_core.documents import Document


class SupportDocumentLoader:

    def load(self, file_path: str):
        path = Path(file_path)
        if path.suffix == ".json":
            return self._load_json(path)
        elif path.suffix == ".xml":
            return self._load_xml(path)
        else:
            raise ValueError("Unsupported file format")

    def _load_json(self, path: Path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        documents = []
        for ticket in data:
            content = f"{ticket.get('subject', '')}\n{ticket.get('body', '')}"
            documents.append(
                Document(
                    page_content=content,
                    metadata={
                        "ticket_id": ticket.get("ticket_id"),
                        "type": ticket.get("type"),
                        "queue": ticket.get("queue"),
                        "priority": ticket.get("priority"),
                        "language": ticket.get("language"),
                        "tags": ticket.get("tags", [])
                    }
                )
            )
        return documents

    def _load_xml(self, path: Path):
        tree = ET.parse(path)
        root = tree.getroot()

        documents = []
        for ticket in root.findall("ticket"):
            content = f"{ticket.findtext('subject')}\n{ticket.findtext('body')}"
            tags = [t.text for t in ticket.find("tags").findall("tag")]

            documents.append(
                Document(
                    page_content=content,
                    metadata={
                        "ticket_id": ticket.findtext("ticket_id"),
                        "type": ticket.findtext("type"),
                        "queue": ticket.findtext("queue"),
                        "priority": ticket.findtext("priority"),
                        "language": ticket.findtext("language"),
                        "tags": tags
                    }
                )
            )
        return documents
