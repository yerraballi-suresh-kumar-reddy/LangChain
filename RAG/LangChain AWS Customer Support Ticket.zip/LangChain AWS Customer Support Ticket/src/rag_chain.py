from langchain_aws import ChatBedrockConverse
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough

class RAGChain:

    def __init__(self, vector_store):
        self.llm = ChatBedrockConverse(
            model="anthropic.claude-3-haiku-20240307-v1:0",
            temperature=0
        )

        self.retriever = vector_store.as_retriever(search_kwargs={"k": 3})

        self.prompt = ChatPromptTemplate.from_template(
            """
            You are a support assistant.
            Use the following context to answer the question.

            Context:
            {context}

            Question:
            {question}
            """
        )

        # Manual RAG chain
        self.chain = (
            {
                "context": self.retriever,
                "question": RunnablePassthrough()
            }
            | self.prompt
            | self.llm
        )

    def run(self, query: str):
        return self.chain.invoke(query)
