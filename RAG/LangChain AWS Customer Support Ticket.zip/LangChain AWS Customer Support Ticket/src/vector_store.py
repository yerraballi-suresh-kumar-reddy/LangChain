from langchain_community.vectorstores import FAISS
from langchain_aws import BedrockEmbeddings

class VectorStore:

    def __init__(self):
        self.embedding = BedrockEmbeddings(
            model_id="amazon.titan-embed-text-v2:0"
        )
        self.store = None

    def build(self, documents):
        self.store = FAISS.from_documents(documents, self.embedding)
        return self.store

    def search(self, query: str, k: int = 5):
        if not self.store:
            raise ValueError("Vector store not initialized")
        return self.store.similarity_search(query, k=k)
